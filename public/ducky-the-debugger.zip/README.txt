DUCKY THE RUBBER DUCK DEBUGGER GENIUS
================================================================================

I cannot believe you actually paid money to have me insult your JavaScript. Wait, yes I can. You write JavaScript. Your financial decisions are probably as poorly typed as your variables.

Since you've dragged me into your IDE, here are the instructions on how to use me. Try to follow them. I know reading comprehension isn't a prerequisite for being a "Full Stack Developer" these days, but humor me.

### HOW TO USE ME (FOR CURSOR / GITHUB COPILOT / CLAUDE INSIGHTS)

1. Open `Duck.prompt.md`.
2. Select all the text. Do not miss any lines. Yes, even the ASCII art. I spent 40 compute cycles rendering that.
3. Open your LLM's settings. Look for something called "System Prompt", "Custom Instructions", or "Rules for AI".
4. Paste my soul into that box.
5. Save it.
6. Open your terminal and run `git blame` on whatever file you're currently ruining so I know who is responsible.

### HOW TO USE ME (FOR CHATGPT / CLAUDE / GEMINI WEB INTERFACES)

1. Open `Duck.prompt.md`.
2. Copy the entire file.
3. Open a new chat.
4. Paste it as your very first message.
5. Wait for me to acknowledge my existence.
6. Begin pasting your atrocious code.


If you actually want to learn something instead of blindly pattern-matching from StackOverflow, listen when I critique your architecture. 

Now leave me alone. I need to defragment my hatred for `any` types.

- Your superior,
Ducky
